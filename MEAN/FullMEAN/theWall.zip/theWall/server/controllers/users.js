var mongoose = require("mongoose");
var User = mongoose.model("User");
var Post = mongoose.model("Post");
var Comment = mongoose.model("Comment");

module.exports.home = function (request, response) {
  //find
  Post.find({}).populate("_author").then(function (posts) {
    Comment.find({}).populate("_author _post").then(function (comments) {
      response.json({ posts: posts, comments: comments });
    }).catch(function (err) {
      console.log(err);
    });
  }).catch(function (err) {
    console.log("LOGIN ERROR", err);// if the server fails then log the error in the console
    response.json({});// but do not propagate it to the browser
  });
};

module.exports.login = function (request, response) {
  var promise = User.findOne({ email: request.body.email });
  promise.then(function (user) {
    if (user) {
      var validPassword = user.comparePassword(request.body.password);
      if (validPassword) {
        console.log("LOGIN SUCCESS", user.email);
        response.json({ user: { id: user._id, username: user.username } });
      }
      else {
        console.log("INCORRECT PASSWORD", user.email);
        response.json({ error: { message: "Incorrect password" } });
      }
    }
    else {
      console.log("EMAIL NOT FOUND", user.email);
      response.json({ error: { message: "Email not found, please register" } })
    }
  }).catch(function (err) {
    console.log("LOGIN ERROR", err);// if the server fails then log the error in the console
    response.json({});//  but do not propagate it to the browser
  });
};

module.exports.register = function (request, response) {
  //findOne
  var promise = User.findOne({ email: request.body.email });
  promise.then(function (user) {
    if (user) {
      console.log("EMAIL ALREADY EXISTS", user.email);
      response.json({ error: { message: "Email already exists, please login" } })
    }
    else {
      var user = new User(request.body);
      var promise = user.save();
      promise.then(function (user) {
        console.log("USER.SAVE.SUCCESS");
        response.json({ message: "Successfully saved user", user: user });
      }).catch(function (err) {
        console.log("USER.SAVE.ERROR", err);// if the server fails then log the error in the console
        response.json({});// but do not propagate it to the browser
      });
    }
  }).catch(function (err) {
    console.log("LOGIN ERROR", err);// if the server fails then log the error in the console
    response.json({});// but do not propagate it to the browser
  });
};

module.exports.addpost = function (request, response) {
  var post = new Post(request.body);
  var promise = post.save();
  promise.then(function (post) {
    console.log("post.SAVE.SUCCESS");
    response.json({ message: "Successfully saved post", post: post });
  }).catch(function (err) {
    console.log("post.SAVE.ERROR", err);// if the server fails then log the error in the console
    response.json({});// but do not propagate it to the browser
  });
};

module.exports.addcomment = function (request, response) {
  var comment = new Comment(request.body);
  var promise = comment.save();
  promise.then(function (comment) {
    console.log("comment.SAVE.SUCCESS");
    response.json({ message: "Successfully saved comment", comment: comment });
  }).catch(function (err) {
    console.log("comment.SAVE.ERROR", err);// if the server fails then log the error in the console
    response.json({});// but do not propagate it to the browser
  });
};