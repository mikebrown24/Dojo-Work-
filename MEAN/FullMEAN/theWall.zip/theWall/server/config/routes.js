var users = require("../controllers/users");
module.exports = function (app)
{
    app.post("/api/users", users.register);
    app.post("/api/login", users.login);
    app.post("/api/posts", users.addpost);
    app.get("/api/posts", users.home);
    app.post("/api/comments", users.addcomment);
    app.get("/api/comments", users.home);
};